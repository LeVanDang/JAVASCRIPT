package com.org.training.services;

import java.util.List;

import com.org.training.dao.UserDao;
import com.org.training.dto.UserDto;

public class UserServicesImpl implements UserServices {

	private UserDao userDao;
	
	/**
	 * @return the userDao
	 */
	public UserDao getUserDao() {
		return userDao;
	}
	/**
	 * @param userDao the userDao to set
	 */
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public boolean deleteUser(UserDto userDto) {
		// TODO Auto-generated method stub
		return userDao.deleteUser(userDto);
		
	}

	public List<UserDto> getAllUser() {
		// TODO Auto-generated method stub
		return userDao.getAllUser();
	}

	public boolean insertUser(UserDto userDto) {
		// TODO Auto-generated method stub
		return userDao.insertUser(userDto);
	}

	public boolean updateUser(UserDto userDto) {
		// TODO Auto-generated method stub
		return userDao.updateUser(userDto);
	}

}
