package com.org.training;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.org.training.dto.UserDto;
import com.org.training.services.UserServices;

public class Main01 {
	
		
	public static void main(String[] args){

		/*
		 * Code using Dependency Injection in Spring Framework
		 */
		BeanFactory bf = new XmlBeanFactory(
						 new FileSystemResource("beans.xml"));

		//UserDto user01 = (UserDto) bf.getBean("user01");
		//System.out.println("UserName: " + user01.getUserName() + 
							//" Password: " + user01.getPassword());

		UserDto user02 = (UserDto) bf.getBean("user02");
		System.out.println("UserName: " + user02.getUserName() + 
							" Password: " + user02.getPassword());

		//UserDto user03 = (UserDto) bf.getBean("user03");
		//System.out.println("UserName: " + user03.getUserName() + 
		//					" Password: " + user03.getPassword());

		//UserDto user04 = (UserDto) bf.getBean("user04");
		//System.out.println("UserName: " + user04.getUserName() + 
		//					" Password: " + user04.getPassword());

		UserServices userService = (UserServices) bf.getBean("userService");
		userService.insertUser(user02);
	}
}
