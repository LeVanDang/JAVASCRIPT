package training;

import java.lang.reflect.Method;

import org.springframework.aop.support.DynamicMethodMatcherPointcut;

public class DynammicPointcut extends DynamicMethodMatcherPointcut {

	public boolean matches(Method method, Class clazz, Object[] obj) {
		System.out.println("Parameter is: " + obj[0].toString());
		if (method.getName().equals("myMethod") && obj[0].equals("run")){
			return true;
		}
		return false;
	}
}
