package com.org.training.sample05.main;

import org.springframework.aop.framework.ProxyFactory;

import com.org.training.sample05.advices.SimpleAroundAdvice;
import com.org.training.sample05.beans.SimpleBean;

/**
 * This is a main class
 * This is a example demontrate 
 * how to use MethodInterceptor in Spring AOP
 * @author dnguyen2
 *
 */
public class Main01 {
	public static void main(String args[]){
		
		//Create proxy object
		ProxyFactory factory = new ProxyFactory();
		
		//Create advice object
		SimpleAroundAdvice advice = new SimpleAroundAdvice();
		
		//Create target object
		SimpleBean target = new SimpleBean();
		
		//Add advice and set target into ProxyFactory
		factory.addAdvice(advice);
		factory.setTarget(target);
		
		//Get SimpleBean object from proxy
		SimpleBean simpleBean = (SimpleBean)factory.getProxy();
		
		//Execute method in SimpleBean object
		target.run();
		simpleBean.run();
		
		
		
	}
}
