package com.org.training.sample05.main;

import org.springframework.aop.Advisor;
import org.springframework.aop.Pointcut;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;

import com.org.training.sample05.advices.SimpleAroundAdvice;
import com.org.training.sample05.beans.SimpleBean;
import com.org.training.sample05.pointscut.SimpleDynamicMethodMatcherPointcut;

/**
 * This is a example using DynamicMethodMatcherPointcut
 * @author dnguyen2
 *
 */
public class Main06 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Create proxy object
		ProxyFactory factory = new ProxyFactory();

		// Create advice object
		SimpleAroundAdvice advice = new SimpleAroundAdvice();

		// Create target object
		SimpleBean target = new SimpleBean();

		// Create new Poitntcut object
		Pointcut pc = new SimpleDynamicMethodMatcherPointcut();

		// Create new Advisor object
		Advisor advisor = new DefaultPointcutAdvisor(pc, advice);

		// Add Advisor and set target into ProxyFactory
		factory.addAdvisor(advisor);
		factory.setTarget(target);

		// Get SimpleBean object from proxy
		SimpleBean simpleBean = (SimpleBean) factory.getProxy();

		// Execute method in SimpleBean object
		simpleBean.testDynamicPointcut(12, 2);
		simpleBean.testDynamicPointcut(1, 2);
	}

}
