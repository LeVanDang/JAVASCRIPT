package com.org.training.sample05.advices;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;

public class SimpleAfterReturningAdvice implements AfterReturningAdvice {

	/**
	 * Method implements of AfterReturningAdvice interface
	 */
	public void afterReturning(Object returnValue, Method method, Object[] args,
			Object target) throws Throwable {
		
		int intValue = ((Integer)returnValue).intValue();
		
		if (intValue % 10 ==0){
			System.out.println("Configuration!!You have ten points");
		}else{
			System.out.println("Please try again!!!!");
		}
		
	}
}
