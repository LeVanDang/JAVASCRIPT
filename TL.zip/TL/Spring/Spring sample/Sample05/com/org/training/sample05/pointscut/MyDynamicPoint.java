package com.org.training.sample05.pointscut;

import java.lang.reflect.Method;

import org.springframework.aop.support.DynamicMethodMatcherPointcutAdvisor;

public class MyDynamicPoint extends DynamicMethodMatcherPointcutAdvisor {

	public boolean matches(Method arg0, Class arg1, Object[] arg2) {
		// TODO Auto-generated method stub
		return false;
	}

}
