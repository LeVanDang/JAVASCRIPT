package com.org.training.sample05.main;

import org.springframework.aop.framework.ProxyFactory;

import com.org.training.sample05.advices.SimpleBeforeAdvice;
import com.org.training.sample05.beans.SimpleBean;

public class Main02 {
	public static void main(String args[]) {

		// Create proxy object
		ProxyFactory factory = new ProxyFactory();

		// Create advice object
		SimpleBeforeAdvice advice = new SimpleBeforeAdvice();

		// Create target object
		SimpleBean target = new SimpleBean();

		// Add advice and set target into ProxyFactory
		factory.addAdvice(advice);
		factory.setTarget(target);

		// Get SimpleBean object from proxy
		SimpleBean simpleBean = (SimpleBean) factory.getProxy();

		// Execute method in SimpleBean object
		target.run();
		simpleBean.run();

	}
}
