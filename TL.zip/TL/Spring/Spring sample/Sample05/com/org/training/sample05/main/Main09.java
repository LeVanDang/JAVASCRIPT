package com.org.training.sample05.main;

import org.springframework.aop.Advisor;
import org.springframework.aop.Pointcut;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;

import training.DynammicPointcut;

import com.org.training.sample05.advices.SimpleAroundAdvice;
import com.org.training.sample05.beans.SimpleBean;

public class Main09 {
	public static void main(String[] args) {
		ProxyFactory factory = new ProxyFactory();
		SimpleAroundAdvice advice = new SimpleAroundAdvice();
		SimpleBean target = new SimpleBean();
		Pointcut pc = new DynammicPointcut();
		Advisor advisor = new DefaultPointcutAdvisor(pc, advice);
		factory.addAdvisor(advisor);
		factory.setTarget(target);
		
		target = (SimpleBean) factory.getProxy();
		target.myMethod("run");
	}
}
