package com.org.training.sample05.main;


import org.springframework.aop.framework.ProxyFactory;

import com.org.training.sample05.advices.SimpleAfterReturningAdvice;
import com.org.training.sample05.beans.SimpleBean;

public class Main04 {
	public static void main(String args[]) {

		// Create proxy object
		ProxyFactory factory = new ProxyFactory();

		// Create advice object
		SimpleAfterReturningAdvice advice = new SimpleAfterReturningAdvice();

		// Create target object
		SimpleBean target = new SimpleBean();

		// Add advice and set target into ProxyFactory
		factory.addAdvice(advice);
		factory.setTarget(target);

		// Get SimpleBean object from proxy
		SimpleBean simpleBean = (SimpleBean) factory.getProxy();

		// Execute method in SimpleBean object
		simpleBean.add(1, 2, 7);
		simpleBean.add(1, 2, 6);

	}
}
