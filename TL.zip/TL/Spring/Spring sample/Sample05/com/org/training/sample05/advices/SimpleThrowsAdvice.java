package com.org.training.sample05.advices;

import java.lang.reflect.Method;
import java.sql.SQLException;

import org.springframework.aop.ThrowsAdvice;

public class SimpleThrowsAdvice implements ThrowsAdvice {

	public void afterThrowing(Exception ex) throws Throwable {
		System.out.println("***");
		System.out.println("Generic Exception Capture");
		System.out.println("Caught: " + ex.getClass().getName());
		System.out.println("***\n");
	}

	public void afterThrowing(Method method, Object[] args, Object target,
			SQLException sex) {
		System.out.println("**********************");
		System.out.println("SQLException Capture occurent at "
				+ method.getName() + "()");
		System.out.println("Caught: " + sex.getClass().getName());
		System.out.println("**********************\n");
	}

}
