package com.org.training.sample05.pointscut;

import java.lang.reflect.Method;

import org.springframework.aop.ClassFilter;
import org.springframework.aop.support.StaticMethodMatcherPointcut;

import com.org.training.sample05.beans.SimpleBean;

public class SimpleStaticMethodMatcherPoincut extends 
							StaticMethodMatcherPointcut {

	/*
	 * This method return TRUE if method and clazz applies to advice, otherwise
	 * (non-Javadoc)
	 * @see org.springframework.aop.MethodMatcher
	 * #matches(java.lang.reflect.Method, java.lang.Class)
	 */
	public boolean matches(Method method, Class clazz) {
		System.out.println(method.getName() + " " + "testStaticPointCut".equals(method.getName()));
		return ("testStaticPointCut".equals(method.getName()));
	}

	/* 
	 * This method should override the method getClassFilter()
	 * It should be return ClassFilter object
	 * (non-Javadoc)
	 * @see org.springframework.aop.support.StaticMethodMatcherPointcut
	 * #getClassFilter()
	 */
	@Override
	public ClassFilter getClassFilter() {
		// TODO Auto-generated method stub
		return new ClassFilter(){
			public boolean matches(Class clazz) {
				return (clazz == SimpleBean.class);
			}
		};
	}

}
