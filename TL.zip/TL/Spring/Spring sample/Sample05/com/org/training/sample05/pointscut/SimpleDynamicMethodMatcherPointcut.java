package com.org.training.sample05.pointscut;

import java.lang.reflect.Method;

import org.springframework.aop.ClassFilter;
import org.springframework.aop.support.DynamicMethodMatcherPointcut;

import com.org.training.sample05.beans.SimpleBean;

public class SimpleDynamicMethodMatcherPointcut extends
		DynamicMethodMatcherPointcut {

	public boolean matches(Method method, Class clazz, Object[] args) {
		
		int a = ((Integer)args[0]).intValue();
		
		if (a != 1){
			return false;
		}else{
			return true;
		}
	}

	/* (non-Javadoc)
	 * @see org.springframework.aop.support.DynamicMethodMatcherPointcut
	 * #getClassFilter()
	 */
	@Override
	public ClassFilter getClassFilter() {		
		return new ClassFilter(){
			public boolean matches(Class clazz) {
				return (clazz == SimpleBean.class);
			}			
		};
	}
	
	

}
