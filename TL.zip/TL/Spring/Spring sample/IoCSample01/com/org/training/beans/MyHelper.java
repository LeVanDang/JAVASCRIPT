package com.org.training.beans;

public class MyHelper {
    public void doSomethingHelpful() {
        //System.out.println("Do some thing");
    }

}
