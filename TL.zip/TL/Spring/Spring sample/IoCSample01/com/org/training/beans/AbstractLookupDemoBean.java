package com.org.training.beans;

public abstract class AbstractLookupDemoBean implements DemoBean {
    public abstract MyHelper getMyHelper();
    
    public void someOperation() {
        getMyHelper().doSomethingHelpful();
    }

}
