package com.org.training.sample03.beans;

public class Bean1 {
	public void operation01(){
		System.out.println("You call method operation01 of Bean1");
	}
}
