package com.org.training.sample03.beans;

public class Bean2 {
	private Bean1 bean1;

	/**
	 * @return the bean1
	 */
	public Bean1 getBean1() {
		return bean1;
	}

	/**
	 * @param bean1 the bean1 to set
	 */
	public void setBean1(Bean1 bean1) {
		this.bean1 = bean1;
	}
	
	public void operation2(){
		bean1.operation01();
		System.out.println("You have call method operation 2 of Bean2");
	}
}
