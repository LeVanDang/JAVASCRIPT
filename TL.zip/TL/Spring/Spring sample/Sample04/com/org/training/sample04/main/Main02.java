package com.org.training.sample04.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.org.training.sample04.event.Publisher;

public class Main02 {

	/**
	 * @param args
	 */
    public static void main(String[] args) {
    	
    	System.out.println("Start main method");
    	
        ApplicationContext ctx01 = new FileSystemXmlApplicationContext("beans02.xml");
    
        System.out.println("CTX01 HashCode: " + ctx01.hashCode());
        
        Publisher pub = (Publisher) ctx01.getBean("publisher01");
        pub.publish("Hello World!");
        pub.publish("The quick brown fox jumped over the lazy dog");
    }

}
