package com.org.training.sample04.event;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.FileSystemXmlApplicationContext;
    
public class Publisher implements ApplicationContextAware {
    
	public Publisher(){
		System.out.println("Contructor Publisher Class");
	}
	
    private ApplicationContext ctx;
        
    public void setApplicationContext(ApplicationContext applicationContext)
            throws BeansException {
    	System.out.println("Start Set Application Context");
    	MessageEventListener mel = (MessageEventListener) 
    			applicationContext.getBean("messageEventListener");
    	System.out.println("MEL HashCode: " + applicationContext.hashCode());
        this.ctx = applicationContext;
    
    }
    
    public void publish(String message) {
        ctx.publishEvent(new MessageEvent(this, message));
    }
}
