package com.org.training.filter;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.CORBA.Request;

public class LocateFilter implements Filter {

	private static String language = "en";
	
	private final static String LOCALE_KEY = "org.apache.struts.action.LOCALE";
	
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	public void doFilter(ServletRequest req, 
						 ServletResponse res, 
						 FilterChain chain) 
			throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		
/*		
		if (req.getParameter("language") != null){
			language = (String)req.getParameter("language");
		}
		Locale locate = new Locale(language);
		Locale.setDefault(locate);
		
		//Set locale language to session
		request.getSession().setAttribute(LOCALE_KEY, locate);
		*/
		String requestURI = request.getRequestURI();
		if (requestURI.endsWith("/welcome.do") ||
			requestURI.endsWith("/login.do")){
			chain.doFilter(request, response);
			return;
		}
		
		if (request.getSession().getAttribute("USER_INFOR") == null){
			RequestDispatcher dispatch = request.getRequestDispatcher("/welcome.do");
			dispatch.forward(request, response);
			return;
		}
		
		chain.doFilter(request, response);		
	}

	public void destroy() {
		// TODO Auto-generated method stub
		
	}

}
