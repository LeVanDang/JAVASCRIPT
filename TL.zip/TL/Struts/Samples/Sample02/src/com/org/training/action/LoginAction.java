package com.org.training.action;

import java.util.List;
import java.util.Locale;

import javax.jms.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.org.training.form.LoginForm;
import com.org.training.utils.DtoUser;
import com.org.training.utils.Utils;

public class LoginAction extends Action {
	
	private final String USER_INFOR = "USER_INFOR";
	
	private final String LOCALE_KEY = "org.apache.struts.action.LOCALE";
	

	@SuppressWarnings("deprecation")
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		LoginForm loginForm = (LoginForm) form;
		
		List<DtoUser> listUser = Utils.getListUsers();
		
		for (int i = 0; i < listUser.size(); i++){
			if (loginForm.getUsername().equals(listUser.get(i).getUserName()) &&
				loginForm.getPassword().equals(listUser.get(i).getPassword())){
				
				//Store data into session
				request.getSession().setAttribute(USER_INFOR, listUser.get(i));
				
				//Set locale language to session
				Locale locate = new Locale(listUser.get(i).getLanguage());
				
				
				Locale.setDefault(locate);
				request.getSession().setAttribute(LOCALE_KEY, locate);
				
				return mapping.findForward("success");
			}
			
		}
		ActionErrors errors = new ActionErrors();
		errors.add(ActionErrors.GLOBAL_ERROR, new ActionMessage(
					"login.invalid"));
		this.saveErrors(request, errors);

		return mapping.getInputForward();
	}
}
