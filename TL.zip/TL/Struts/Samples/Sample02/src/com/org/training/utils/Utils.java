package com.org.training.utils;

import java.util.ArrayList;
import java.util.List;

public class Utils {
	private static List<DtoUser> listUsers = new ArrayList<DtoUser>();

	private static List<DtoBook> listBooks = new ArrayList<DtoBook>();

	// Init data to user list and books list
	static {
		for (int i = 1; i < 10; i++) {

			DtoUser objUser = new DtoUser();
			objUser.setUserName("DungNT" + i);
			objUser.setPassword("123456");
			if (i  % 2 == 0){
				objUser.setLanguage("en");
			}else{
				objUser.setLanguage("ja");
			}
			listUsers.add(objUser);

			DtoBook objBook = new DtoBook();
			objBook.setBookId(i);
			objBook.setBookTitle("Title " + i);
			objBook.setBookAuthor("DungNT " + i);
			objBook.setBookAvailable(true);
			
			listBooks.add(objBook);
		}

	}

	public static List<DtoBook> getListBooks() {
		return listBooks;
	}

	public static void setListBooks(List<DtoBook> listBooks) {
		Utils.listBooks = listBooks;
	}

	public static List<DtoUser> getListUsers() {
		return listUsers;
	}

	public static void setListUsers(List<DtoUser> listUsers) {
		Utils.listUsers = listUsers;
	}

}
