package com.org.training.form;

import org.apache.struts.action.ActionForm;

public class NullForm extends ActionForm {

	/**
	 * This is serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

}
