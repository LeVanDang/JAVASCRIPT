package com.org.training.beans;

public interface DemoBean {
    public MyHelper getMyHelper();
    public void someOperation();

}
