package com.org.training.mains;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.util.StopWatch;

import com.org.training.beans.DemoBean;
import com.org.training.beans.MyHelper;

/**
 * This is a example using lookup method
 * @author DungNT
 *
 */
public class Main01 {

	public static void main(String[] args) {
        BeanFactory factory = new XmlBeanFactory(new FileSystemResource(
                "applicationContext.xml"));
    
        DemoBean abstractBean = (DemoBean) factory.getBean("abstractLookupBean");
        DemoBean standardBean = (DemoBean) factory.getBean("standardLookupBean");
    
        displayInfo(standardBean);
        displayInfo(abstractBean);
    
    }
    
    public static void displayInfo(DemoBean bean) {
        MyHelper helper1 = bean.getMyHelper();
        MyHelper helper2 = bean.getMyHelper();
    
        System.out.println("Helper Instances the Same?: "
                + (helper1 == helper2));
    
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("lookupDemo");
    
        for (int x = 0; x < 100000; x++) {
            MyHelper helper = bean.getMyHelper();
            helper.doSomethingHelpful();
        }
    
        stopWatch.stop();
    
        System.out.println("100000 gets took " + stopWatch.getTotalTimeMillis()
                + " ms");
    
    }


}
