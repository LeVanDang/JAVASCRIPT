package com.org.training.sample03.beans;

public class ParentBean {
	
	private String name;
	
	private int age;
	
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	public ParentBean(){
		System.out.println("You have contructor ParentBean");
	}
}
