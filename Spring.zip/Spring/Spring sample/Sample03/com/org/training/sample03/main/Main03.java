package com.org.training.sample03.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.org.training.sample03.beans.ChildBean;
import com.org.training.sample03.beans.ParentBean;

public class Main03 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory factory = new XmlBeanFactory(
				  new FileSystemResource("beans03.xml") );
		
		ParentBean childBean = (ParentBean)factory.getBean("child");
		System.out.println("UserName: " + childBean.getName() +
						   " Age: " + childBean.getAge());
		try{
		ParentBean parentBean = (ParentBean)factory.getBean("parent");
		System.out.println("UserName: " + parentBean.getName() +
				   		   " Age: " + parentBean.getAge());
		}catch(Exception ex){
			System.out.println(ex.toString());
		}
	}

}
