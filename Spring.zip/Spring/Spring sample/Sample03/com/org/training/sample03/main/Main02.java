package com.org.training.sample03.main;

import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.org.training.sample03.beans.CollectionInjection;

public class Main02 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory factory = new XmlBeanFactory(
							  new FileSystemResource("beans02.xml") );
		
		CollectionInjection collect = 
			(CollectionInjection)factory.getBean("collectionInjection");
		
		Map map = collect.getMap();
		Iterator i = map.keySet().iterator();
		
		while (i.hasNext()){
			 Object key = i.next();
	         System.out.println("Key: " + key + " - Value: " + map.get(key));

		}
	}

}
