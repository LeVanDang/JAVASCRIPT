package com.org.training.sample03.beans;

public class ChildBean extends ParentBean {
	public ChildBean(){
		System.out.println("You have contructor ChildBean");
	}
}
