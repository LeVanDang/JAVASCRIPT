package com.org.training.sample03.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.org.training.sample03.beans.Bean2;
import com.org.training.sample03.beans.SimpleBean;

public class Main01 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		 TODO Auto-generated method stub
		BeanFactory paretnFactory = new XmlBeanFactory(new 
							 FileSystemResource("parent.xml"));
		
		// TODO Auto-generated method stub
		BeanFactory childFactory = new XmlBeanFactory(new 
							 FileSystemResource("beans.xml"),paretnFactory);
		
		/*
		Bean2 bean2 = (Bean2)factory.getBean("bean2");		
		bean2.operation2();
		*/
		SimpleBean target1 = (SimpleBean)childFactory.getBean("target1");
		SimpleBean target2 = (SimpleBean)childFactory.getBean("target2");
		SimpleBean target3 = (SimpleBean)childFactory.getBean("target3");
		
		System.out.println("Test value of Target 1: " + target1.getValueTest());
		System.out.println("Test value of Target 2: " + target2.getValueTest());
		System.out.println("Test value of Target 3: " + target3.getValueTest());
		
	}

}
