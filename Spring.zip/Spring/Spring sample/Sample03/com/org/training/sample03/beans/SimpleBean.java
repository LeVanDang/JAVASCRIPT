package com.org.training.sample03.beans;

public class SimpleBean {
	private String valueTest;

	/**
	 * @return the valueTest
	 */
	public String getValueTest() {
		return valueTest;
	}

	/**
	 * @param valueTest the valueTest to set
	 */
	public void setValueTest(String valueTest) {
		this.valueTest = valueTest;
	}
	
	
}
