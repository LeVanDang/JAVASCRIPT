package com.org.training.sample04.main;

import java.io.IOException;
import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.io.Resource;

public class Main01 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new FileSystemXmlApplicationContext("beans01.xml");
		
		Locale locale01 = new Locale("en", "US");
		Locale locale02 = new Locale("ja", "JP");
		Locale locale03 = new Locale("fr");
		
		System.out.println(context.getMessage("button01",null, locale01 ));
		System.out.println(context.getMessage("button01",null, locale02 ));
		System.out.println(context.getMessage("button01",null, locale03 ));
		
		Resource resource = context.getResource("file:///C:/abc.txt");
		try {
			System.out.println(resource.getInputStream().toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
