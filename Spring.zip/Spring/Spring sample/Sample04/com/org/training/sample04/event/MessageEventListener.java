package com.org.training.sample04.event;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
    
public class MessageEventListener implements ApplicationListener {
    
	public MessageEventListener(){
		System.out.println("Contructor MessageEventListener");
	}
   
    public void onApplicationEvent(ApplicationEvent event) {
       if(event instanceof MessageEvent) {
           MessageEvent msgEvt = (MessageEvent)event;
           System.out.println("Received: " + msgEvt.getMessage());
       }
    }
}