/**
 * 
 */
package com.org.sample.test;

import org.apache.log4j.Category;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;
import org.apache.log4j.xml.DOMConfigurator;

/**
 * @author DungNT
 * 
 */
public class Sample {
	//static Logger logger = Logger.getLogger(Sample.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		PropertyConfigurator
				.configure("com/org/sample/resource/log4j.properties");

		Logger log = Logger.getLogger(Sample.class);

		log.info("Start Program sampe");
		*/
		/*
		 * SimpleLayout layout = new SimpleLayout();
		 * 
		 * FileAppender appender = null; try { appender = new
		 * FileAppender(layout, "output1.txt", false); } catch (Exception e) { }
		 * logger.addAppender(appender); logger.setLevel((Level) Level.DEBUG);
		 * 
		 * logger.debug("Here is some DEBUG"); logger.info("Here is some INFO");
		 * logger.warn("Here is some WARN"); logger.error("Here is some ERROR");
		 * logger.fatal("Here is some FATAL");
		 */
		
		DOMConfigurator.configure("com/org/sample/resource/log4j.xml");
		Logger log = Logger.getLogger(Sample.class);
		log.info("Start Program sampe");
		
		System.out.println("This is a sample using log4j");
	}
}
