package com.org.training.sample05.advices;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

public class SimpleBeforeAdvice implements MethodBeforeAdvice {

	public void before(Method method, Object[] objects, Object object)
			throws Throwable {
		System.out.println("Before call method " + method.getName() + "()");
	}
}
