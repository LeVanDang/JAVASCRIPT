package com.org.training.sample05.advices;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
/**
 * This is a class implements MethodInterceptor interface
 * This implements allow you can insert code before and after 
 * the main business is execcuted
 * @author dnguyen2
 *
 */
public class SimpleAroundAdvice implements MethodInterceptor {

	public Object invoke(MethodInvocation invocation) throws Throwable {
		//Insert business code before call method
		System.out.println("Before call " + invocation.getMethod().getName());
		
		//Process main business of method
		Object object = invocation.proceed();
		
		//Insert business code after call method
		System.out.println("After call " + invocation.getMethod().getName());
		
		return object;
	}
}
