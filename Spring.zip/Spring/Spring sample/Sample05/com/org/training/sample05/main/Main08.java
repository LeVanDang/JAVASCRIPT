package com.org.training.sample05.main;

import org.springframework.aop.Advisor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.NameMatchMethodPointcut;


import com.org.training.sample05.advices.SimpleAroundAdvice;
import com.org.training.sample05.beans.SimpleBean;

/**
 * This is a example using NameMatchMethodPointcutAdvisor
 * 
 * @author dnguyen2
 * 
 */
public class Main08 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Create proxy object
		ProxyFactory factory = new ProxyFactory();

		// Create advice object
		SimpleAroundAdvice advice = new SimpleAroundAdvice();

		// Create target object
		SimpleBean target = new SimpleBean();

		// Create new Poitntcut object
		NameMatchMethodPointcut pc = new NameMatchMethodPointcut();
		pc.addMethodName("testDynamicPointcut");
				
		// Create new Advisor object
		Advisor advisor = new DefaultPointcutAdvisor(pc, advice);

		// Add Advisor and set target into ProxyFactory
		factory.addAdvisor(advisor);
		factory.setTarget(target);

		// Get SimpleBean object from proxy
		SimpleBean simpleBean = (SimpleBean) factory.getProxy();

		// Execute method in SimpleBean object
		target.testDynamicPointcut(12, 2);
		simpleBean.testDynamicPointcut(1, 2);
		simpleBean.run();
		simpleBean.testStaticPointCut();

	}

}
