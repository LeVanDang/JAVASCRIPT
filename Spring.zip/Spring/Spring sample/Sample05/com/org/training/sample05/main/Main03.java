package com.org.training.sample05.main;

import org.springframework.aop.framework.ProxyFactory;

import com.org.training.sample05.advices.SimpleThrowsAdvice;
import com.org.training.sample05.beans.SimpleBean;

public class Main03 {
	public static void main(String args[]) throws Exception {

		// Create proxy object
		ProxyFactory factory = new ProxyFactory();

		// Create advice object
		SimpleThrowsAdvice advice = new SimpleThrowsAdvice();

		// Create target object
		SimpleBean target = new SimpleBean();

		// Add advice and set target into ProxyFactory
		factory.addAdvice(advice);
		factory.setTarget(target);

		// Get SimpleBean object from proxy
		SimpleBean simpleBean = (SimpleBean) factory.getProxy();

		try {
			// Execute method in SimpleBean object
			simpleBean.raiseException();
		} catch (Exception ex) {
			System.out.println(ex.toString());
		}

	}
}
