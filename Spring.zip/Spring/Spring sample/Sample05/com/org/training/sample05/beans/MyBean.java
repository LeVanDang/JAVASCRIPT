package com.org.training.sample05.beans;

public class MyBean {

	public void test(){
		System.out.println("test method run");
	}
	
	public void testA(){
		System.out.println("testA method run");
	}
	
	public void AtestA(){
		System.out.println("AtestA method run");
	}
}
