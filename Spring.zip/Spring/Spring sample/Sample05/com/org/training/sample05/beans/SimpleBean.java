package com.org.training.sample05.beans;

import java.sql.SQLException;

/**
 * This is a simple bean demontrate for AOP in Spring
 * @author dnguyen2
 *
 */
public class SimpleBean {
	/**
	 * This method for test AroundAdvice and 
	 * BeforeAdvice interfaces
	 */
	public void run(){
		System.out.println("You are called run() method. ");		
	}
	
	/**
	 * This is method for test ThrowsAdvice interface
	 * @throws Exception
	 */
	public void raiseException() throws Exception{
		throw new SQLException("This is test Exception");
	}
	
	/**
	 * This is method for test AfterReturningAdvice interface
	 * @param a
	 * @param b
	 * @param c
	 * @return
	 */
	public int add(int a, int b, int c){
		return a+b+c;
	}
	/**
	 * This is a method for test static pointcut
	 *
	 */
	public void testStaticPointCut(){
		System.out.println("You have call testPointCut() method");
	}
	
	public void myMethod(String arg){
		System.out.println("Run myMethod");
	}
	
	/**
	 * This is a method for test dynamic pointcut
	 */
	public void testDynamicPointcut(int a, int b){
		System.out.println("You call testDynamicPointcut() method");
	}
}
