package com.org.training.sample05.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.org.training.sample05.beans.MyBean;

public class Main10 {
	
	public static void main(String[] args){
		ApplicationContext ctx = new FileSystemXmlApplicationContext("myBean.xml");
		MyBean myBean = (MyBean) ctx.getBean("myBean");
		myBean.test();
		myBean.testA();
		myBean.AtestA();
	}
}
