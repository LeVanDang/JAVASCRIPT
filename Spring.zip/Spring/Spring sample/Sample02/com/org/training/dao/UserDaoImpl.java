package com.org.training.dao;

import java.util.List;

import com.org.training.dto.UserDto;

public class UserDaoImpl implements UserDao {

	public boolean deleteUser(UserDto userDto) {
		// TODO Auto-generated method stub
		System.out.println("You have delete a user");
		return false;
	}

	public List<UserDto> getAllUser() {
		// TODO Auto-generated method stub
		System.out.println("You have get a list user");
		return null;
	}

	public boolean insertUser(UserDto userDto) {
		// TODO Auto-generated method stub
		System.out.println("You have insert a user");
		return false;
	}

	public boolean updateUser(UserDto userDto) {
		// TODO Auto-generated method stub
		System.out.println("You have update a user");
		return false;
	}
	
	
	
	
}
