package com.org.training.dao;

import java.util.List;
import com.org.training.dto.UserDto;

public interface UserDao {
	
	public List<UserDto> getAllUser();
	
	public boolean insertUser(UserDto userDto);
	
	public boolean deleteUser(UserDto userDto);
	
	public boolean updateUser(UserDto userDto);
	
}
