package com.org.training.services;

import java.util.List;

import com.org.training.dto.UserDto;

public interface UserServices {
	public List<UserDto> getAllUser();
	
	public boolean insertUser(UserDto userDto);
	
	public boolean deleteUser(UserDto userDto);
	
	public boolean updateUser(UserDto userDto);
}
