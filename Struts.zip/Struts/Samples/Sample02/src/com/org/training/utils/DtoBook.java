package com.org.training.utils;

import java.io.Serializable;



public class DtoBook implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int bookId = 0;
	
	private String bookTitle = null;
	
	private String bookAuthor = null;
	
	private boolean bookAvailable = true;
	
	private boolean flag = false;

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public boolean isBookAvailable() {
		return bookAvailable;
	}

	public void setBookAvailable(boolean bookAvailable) {
		this.bookAvailable = bookAvailable;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
}
