package com.org.training.action;

import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.org.training.form.BookForm;
import com.org.training.utils.DtoBook;
import com.org.training.utils.Utils;

public class UpdateBookAction extends DispatchAction {

	public ActionForward Update(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		BookForm bookForm = (BookForm) form;

		int id = Integer.parseInt(request.getParameter("id"));

		List<DtoBook> listBook = Utils.getListBooks();
		for (int i = 0; i < listBook.size(); i++) {
			if (listBook.get(i).getBookId() == id) {
				bookForm.setBookId(id);
				bookForm.setBookAuthor(listBook.get(i).getBookAuthor());
				bookForm.setBookAvailable(listBook.get(i).isBookAvailable());
				bookForm.setBookTitle(listBook.get(i).getBookTitle());
				break;
			}
		}
		return mapping.findForward("showInsert");
	}

	public ActionForward Insert(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		Random r = new Random();
		BookForm bookForm = (BookForm) form;
		
		int id = (int)(r.nextFloat() * 10000);
		
		bookForm.setBookId(id);
		
		return mapping.findForward("showInsert");
	}

	public ActionForward Delete(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		BookForm bookForm = (BookForm) form;
		
		int id = Integer.parseInt(request.getParameter("id"));

		List<DtoBook> listBook = Utils.getListBooks();
		for (int i = 0; i < listBook.size(); i++) {
			if (listBook.get(i).getBookId() == id) {
				listBook.remove(i);
				break;
			}
		}
		bookForm.setListBooks(Utils.getListBooks());
		return mapping.findForward("success");
	}

	public ActionForward Save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		BookForm bookForm = (BookForm) form;

		int id = bookForm.getBookId();
		
		System.out.println("ID: " + id);
		System.out.println("Avail: " + bookForm.isBookAvailable());
		
		boolean isInsert = true;	
		
		List<DtoBook> listBook = Utils.getListBooks();
		for (int i = 0; i < listBook.size(); i++) {
			if (listBook.get(i).getBookId() == id) {
				
				listBook.get(i).setBookAuthor(bookForm.getBookAuthor());
				listBook.get(i).setBookAvailable(bookForm.isBookAvailable());
				listBook.get(i).setBookTitle(bookForm.getBookTitle());
				
				isInsert = false;
			}
		}
		
		if (isInsert){
			DtoBook objBook = new DtoBook();
			objBook.setBookAuthor(bookForm.getBookAuthor());
			objBook.setBookAvailable(bookForm.isBookAvailable());
			objBook.setBookId(bookForm.getBookId());
			objBook.setBookTitle(bookForm.getBookTitle());
			
			Utils.getListBooks().add(objBook);
		}
		
		bookForm.setListBooks(Utils.getListBooks());
		
		return mapping.findForward("success");
	}

}
