package com.org.training.form;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

public class LoginForm extends ActionForm {

	/**
	 * This id serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String username = null;
	private String password = null;

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public ActionErrors validate(ActionMapping mapping, 
								HttpServletRequest request) {
		
		//Create ActionErrors object
		ActionErrors errors = new ActionErrors();
		
		if (this.getUsername() == null ||
			this.getUsername().length() < 1){
			errors.add(ActionMessages.GLOBAL_MESSAGE,new ActionMessage("login.user.require"));
		}
		
		if (this.getPassword() == null ||
				this.getPassword().length() < 1){
				errors.add(ActionMessages.GLOBAL_MESSAGE,
						   new ActionMessage("login.pass.require"));
			}
		return errors;
	}
}
