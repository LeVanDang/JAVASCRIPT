package com.org.training.form;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.org.training.utils.DtoBook;

public class BookForm extends ActionForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<DtoBook> listBooks = null;

	private int bookId = 0;

	private String bookTitle = null;

	private String bookAuthor = null;

	private boolean bookAvailable = false;
	

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public boolean isBookAvailable() {
		return bookAvailable;
	}

	public void setBookAvailable(boolean bookAvailable) {
		this.bookAvailable = bookAvailable;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public List<DtoBook> getListBooks() {
		return listBooks;
	}

	public void setListBooks(List<DtoBook> listBooks) {
		this.listBooks = listBooks;
	}

	@Override
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
		
		ActionErrors errors = null;
		
		ActionMessage message = null;
		
		if ("Save".equals(request.getParameter("do"))){
			
			errors = new ActionErrors();
			
			if (this.getBookAuthor() == null ||
			    this.getBookAuthor().length() == 0){
				message = new ActionMessage("data.require", "Author");
				errors.add(ActionErrors.GLOBAL_MESSAGE, message);
			}
			if (this.getBookTitle() == null || 
				this.getBookTitle().length() == 0){
				message = new ActionMessage("data.require", "Title");
				errors.add(ActionErrors.GLOBAL_MESSAGE, message);
			}
		}			
		return errors;
		
	}
}
