package com.org.training.action;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.org.training.form.BookForm;
import com.org.training.utils.Utils;

public class ListBookAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse respone)
			throws Exception {

		BookForm bookForm = (BookForm) form;

		bookForm.setListBooks(Utils.getListBooks());

		return mapping.findForward("showListBook");
	}

}
