package com.org.training.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class SampleDispatchAction extends DispatchAction {


	public ActionForward add(ActionMapping mapping, 
			 ActionForm form, 
			 HttpServletRequest requrest, 
			 HttpServletResponse response) throws Exception {
		
		//Add more code add user to here
		
		return mapping.findForward("addSuccess");
		
	}
	
	public ActionForward update(ActionMapping mapping, 
			 ActionForm form, 
			 HttpServletRequest requrest, 
			 HttpServletResponse response) throws Exception {
		
		//Add more code update user to here
		
		return mapping.findForward("updateSuccess");
		
	}

}
