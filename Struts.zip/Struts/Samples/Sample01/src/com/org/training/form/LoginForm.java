package com.org.training.form;

import org.apache.struts.action.ActionForm;

public class LoginForm extends ActionForm {

	/** This is a serialVesionUID */
	private static final long serialVersionUID = 1L;

	private String username = null;
	
	private String password = null;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
//	@SuppressWarnings("deprecation")
//	
//	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
//		ActionErrors errors = new ActionErrors();
//		if (this.getUsername() == null || this.getUsername().length() < 1){
//			errors.add(ActionErrors.GLOBAL_ERROR, 
//					new ActionError("login.username.required", "abcdef"));
//		}
//		
//		if (this.getPassword() == null || this.getPassword().length() < 1){
//			errors.add(ActionErrors.GLOBAL_ERROR, 
//					new ActionError("login.password.required", this.getPassword()));
//		}
//			
//		return errors;
//	}
}
